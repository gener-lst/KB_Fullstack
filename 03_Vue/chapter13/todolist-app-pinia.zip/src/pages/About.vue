<template>
  <div class="card card-body">
    <h2>About</h2>
  </div>
</template>
